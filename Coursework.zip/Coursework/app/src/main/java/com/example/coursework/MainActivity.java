package com.example.coursework;

import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends Activity
{
    private ListView rawDataDisplay;
    private TextView textView;
    // Traffic Scotland URLs
    private String urlSourceRW = "https://trafficscotland.org/rss/feeds/roadworks.aspx";
    private String urlSourcePRW = "https://trafficscotland.org/rss/feeds/plannedroadworks.aspx";
    private String urlSourceCI = "https://trafficscotland.org/rss/feeds/currentincidents.aspx";
    private String xmlSourceRW = "CurrentRoadworks.xml";
    private String xmlSourcePRW="PlannedRoadWorks.xml";
    private String xmlSourceCI="CurrentIncidents.xml";
    List<CurrentIncedents> ci;
    List<RoadWorks> rW;
    List<PlannedRoadWorks> found;

    public void btnClick(View v) throws ParseException {
        rawDataDisplay = findViewById(R.id.rawDataDisplay);
        textView = findViewById(R.id.testing);
        ci = siteXmlPullParser.getCurrentIncedentsFromFile(MainActivity.this);
        rW = siteXmlPullParser.getCurrentRoadWokdsFromFile(MainActivity.this);
        String d = "2/7/2020";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date srchD = sdf.parse(d);
        found = findDate(srchD);
        int size = ci.size();
        String title = ci.get(1).getTitle();
        textView.setText("change: "+ size);
    }

    //get list of PlannedRoadWorks that is happening during user enters date
    public List<PlannedRoadWorks> findDate(Date d){
        Date userDate = d;
        List<PlannedRoadWorks> pRw;
        List<PlannedRoadWorks> rPRw = new ArrayList<>();
        pRw = siteXmlPullParser.getPlannedRoadWorksFromFile(MainActivity.this);
        for (int i=0; i<pRw.size();i++){
            Date startDate = pRw.get(i).getStartDate();
            Date endDate = pRw.get(i).getEndDate();
            if(userDate.after(startDate) && userDate.before(endDate)){
                rPRw.add(pRw.get(i));
            }
        }
        return rPRw;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //if network available will download new feed into suitable area if no network available will use the previous xml downloaded
        if (isNetworkAvailable()){
            SitesDownloadTask download = new SitesDownloadTask();
            download.execute();
        }
    }

    private boolean isNetworkAvailable(){
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetwrokInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetwrokInfo != null && activeNetwrokInfo.isConnected();
    }

    private class SitesDownloadTask extends AsyncTask<Void, Void, Void>{
        @Override
        protected Void doInBackground(Void... arg0){
            //download files
            try{
                //current incidents
                Downloader.DownloadFromUrl(urlSourceCI, openFileOutput(xmlSourceCI,Context.MODE_PRIVATE));
                //current roadworks
                Downloader.DownloadFromUrl(urlSourceRW,openFileOutput(xmlSourceRW,Context.MODE_PRIVATE));
                //planned roadworks
                Downloader.DownloadFromUrl(urlSourcePRW,openFileOutput(xmlSourcePRW,Context.MODE_PRIVATE));
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }
            return null;
        }
    }
} // End of MainActivity
